#define COLOR1 "black"
#define COLOR2 "#005577"
